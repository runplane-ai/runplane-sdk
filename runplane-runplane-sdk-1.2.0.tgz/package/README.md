# @runplane/runplane-sdk

Runplane SDK is the easiest way to use Runplane Guard from code.

Runplane Guard controls execution before actions run. The SDK is a thin wrapper over the Guard API. The decision system runs in the Gateway.

## Core Concept

Runplane does not execute actions. Runplane decides whether actions are allowed to execute.

Every action is stopped and must receive a decision before it runs:

| Decision | Behavior |
|----------|----------|
| `ALLOW` | Execution proceeds immediately |
| `BLOCK` | Execution is stopped |
| `REQUIRE_APPROVAL` | Execution is paused until a human approves or denies |

No action executes without passing through Runplane.

## Why Runplane
AI agents can execute real-world actions: delete data, transfer funds, modify systems.
Runplane gives you a control layer before execution.
- Prevent destructive actions
- Require human approval for risky operations
- Enforce policies in real time
Without Runplane, actions run immediately. With Runplane, every action is verified first.

## 🚀 Get Started in 2 Minutes (Free)

Start using Runplane instantly:

👉 https://runplane.ai/auth/sign-up?mode=developer

- 14-day free trial
- or up to 1,000 decision executions

No setup required. Just create your account and get your API key.

⚠️ The SDK requires a valid API key to run.

## Installation

```bash
npm install @runplane/runplane-sdk
```


## Quick Start
```typescript
import { Shield } from "@runplane/runplane-sdk";

const runplane = new Shield({
  baseUrl: "https://runplane.ai",
  apiKey: process.env.RUNPLANE_API_KEY!,
});

// Guard an action before execution
const result = await runplane.guard(
  "delete_record",           // action type
  "users-database",          // target system
  { recordId: "user_123" },  // context
  async () => {
    // This only runs if Runplane returns ALLOW
    // or if approval is granted for REQUIRE_APPROVAL
    await db.deleteUser("user_123");
    return { deleted: true };
  }
);
```

## What Happens

### ALLOW
The callback executes immediately. Runplane determined the action is safe.

### BLOCK
The callback never runs. A `ShieldError` is thrown with code `"BLOCKED"`.

```typescript
try {
  await runplane.guard("dangerous_action", "production", {}, async () => {
    // Never executes
  });
} catch (err) {
  if (err instanceof ShieldError && err.code === "BLOCKED") {
    console.log("Action blocked:", err.message);
  }
}
```

### REQUIRE_APPROVAL
The SDK automatically waits for human approval:

1. SDK receives `approvalId` from the Guard API
2. SDK polls `/api/v1/approvals/{approvalId}` until resolved
3. If approved: callback executes
4. If denied: `ShieldError` thrown with code `"DENIED"`
5. If timeout: behavior depends on `failMode` configuration

## Configuration

```typescript
const runplane = new Shield({
  baseUrl: "https://your-runplane-instance.com",
  apiKey: process.env.RUNPLANE_API_KEY!,
  
  // Request timeout (default: 3000ms)
  timeoutMs: 3000,
  
  // Fail mode: "closed" (block on error) or "open" (allow on error)
  failMode: "closed",
  
  // Approval polling timeout (default: 300000ms / 5 minutes)
  approvalTimeoutMs: 300000,
  
  // Initial polling interval (default: 2000ms, exponential backoff applied)
  approvalPollIntervalMs: 2000,
});
```

## Approval Flow

When Runplane returns `REQUIRE_APPROVAL`:

```
SDK                          Guard API                    Human
 |                              |                           |
 |-- POST /api/v1/guard ------->|                           |
 |<-- { decision: REQUIRE_APPROVAL, approvalId: "..." } ----|
 |                              |                           |
 |-- GET /api/v1/approvals/{id} (poll) -------------------->|
 |<-- { status: "pending" } ----|                           |
 |                              |                           |
 |          ... (waiting, polling with backoff) ...         |
 |                              |                           |
 |                              |<-- Approve/Deny ----------|
 |                              |                           |
 |-- GET /api/v1/approvals/{id} (poll) -------------------->|
 |<-- { status: "approved" } ---|                           |
 |                              |                           |
 |-- Execute callback -------->                             |
```

## Architecture

Runplane uses a Gateway-first architecture:

- **Guard API** (`/api/v1/guard`) is the primary decision endpoint
- **SDK is optional** - you can call the API directly
- **The API is the control point** - all decisions happen in the Gateway

The SDK is a convenience wrapper. If you prefer direct API calls:

```bash
curl -X POST https://your-instance.com/api/v1/guard \
  -H "Authorization: Bearer $RUNPLANE_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "action": {
      "type": "delete_record",
      "target": "users-database",
      "context": { "recordId": "user_123" }
    }
  }'
```

## Error Handling

### ShieldError

All SDK errors are thrown as `ShieldError` with a `code` property:

| Code | Meaning |
|------|---------|
| `BLOCKED` | Action was blocked by policy |
| `DENIED` | Human approver denied the action |
| `TIMEOUT` | Approval polling timed out |
| `NETWORK_ERROR` | Network or API failure |
| `UNKNOWN` | Unexpected error |

```typescript
import { Shield, ShieldError } from "@runplane/runplane-sdk";

try {
  await runplane.guard("action", "target", {}, async () => {
    // ...
  });
} catch (err) {
  if (err instanceof ShieldError) {
    switch (err.code) {
      case "BLOCKED":
        console.log("Policy blocked this action");
        break;
      case "DENIED":
        console.log("Approver denied:", err.message);
        break;
      case "TIMEOUT":
        console.log("Approval timed out");
        break;
    }
  }
}
```

### Fail-Closed Behavior

By default, the SDK uses `failMode: "closed"`:

- Network errors result in `BLOCK`
- Missing `approvalId` throws an error
- Approval timeout results in `BLOCK`

To allow actions on failure, set `failMode: "open"` (use with caution).

## API Reference

### `guard<T>(actionType, target, context, fn): Promise<T>`

Guard an action before execution.

| Parameter | Type | Description |
|-----------|------|-------------|
| `actionType` | `string` | Canonical action name (e.g., `"delete_record"`) |
| `target` | `string` | Target system identifier |
| `context` | `Record<string, unknown> \| null` | Additional context for policy evaluation |
| `fn` | `() => Promise<T>` | Callback to execute if allowed |

### `decide(req): Promise<DecideResponse>`

Request a decision without executing a callback.

```typescript
const response = await runplane.decide({
  actionType: "transfer_funds",
  target: "banking-api",
  context: { amount: 50000 },
});

if (response.decision === "ALLOW") {
  // Proceed with action
}
```

### `pollApproval(approvalId): Promise<ApprovalPollResponse>`

Poll for approval status. Used internally by `guard()`, but available for custom flows.

## What's New in v1.2.0

### Internal Improvements

- SDK now uses `/api/v1/guard` instead of `/api/decide`
- Approval polling now uses `approvalId` (returned in response)
- Improved error messages for timeouts and denials
- SDK is now explicitly a wrapper over the Gateway

### Compatibility

**Fully backward compatible.** No code changes required.

The `guard()` method signature is unchanged. Existing code continues to work.

### Deprecation Notice

The legacy `/api/decide` endpoint is deprecated but remains functional for backward compatibility. New integrations should use `/api/v1/guard` directly or via this SDK.

## License

MIT
